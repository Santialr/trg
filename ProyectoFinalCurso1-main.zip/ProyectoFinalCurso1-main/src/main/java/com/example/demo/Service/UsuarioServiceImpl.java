package com.example.demo.Service;

import com.example.demo.Controller.ControllerVistas;
import com.example.demo.Database.ConexionBD;
import com.example.demo.Entity.Usuario;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    static ConexionBD connection = new ConexionBD();

    // Método para crear un nuevo usuario en la base de datos
    public static void crearUsuario(Usuario usuario) throws SQLException {
        String insertSql = "INSERT INTO Usuarios (nombre, apellido, edad, email) VALUES (?, ?, ?, ?)";
        PreparedStatement insertStatement = connection.conectar().prepareStatement(insertSql);
        insertStatement.setString(1, usuario.getNombre());
        insertStatement.setString(2, usuario.getApellido());
        insertStatement.setInt(3, usuario.getEdad());
        insertStatement.setString(4, usuario.getEmail());
        insertStatement.executeUpdate();
        System.out.println("Usuario creado exitosamente.");
    }

    // Método para obtener todos los usuarios almacenados en la base de datos
    public List<Usuario> obtenerUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM Usuarios";
        PreparedStatement statement = connection.conectar().prepareStatement(sql);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            Usuario usuario = new Usuario();
            usuario.setId(resultSet.getInt("id"));
            usuario.setNombre(resultSet.getString("nombre"));
            usuario.setApellido(resultSet.getString("apellido"));
            usuario.setEdad(resultSet.getInt("edad"));
            usuario.setEmail(resultSet.getString("email"));
            usuarios.add(usuario);
        }
        return usuarios;
    }

    // Método para buscar un usuario por ID
    public Usuario buscar(int id) throws SQLException {
        String sql = "SELECT * FROM Usuarios WHERE id = ?";
        PreparedStatement statement = connection.conectar().prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            Usuario usuario = new Usuario();
            usuario.setId(resultSet.getInt("id"));
            usuario.setNombre(resultSet.getString("nombre"));
            usuario.setApellido(resultSet.getString("apellido"));
            usuario.setEdad(resultSet.getInt("edad"));
            usuario.setEmail(resultSet.getString("email"));
            return usuario;
        }
        throw new SQLException("Usuario no encontrado");
    }

    // Método para actualizar los datos de un usuario existente en la base de datos
    public static Usuario actualizarUsuario(Usuario usuario) throws SQLException {
        String sql = "UPDATE Usuarios SET nombre = ?, apellido = ?, edad = ?, email = ? WHERE id = ?";
        PreparedStatement statement = connection.conectar().prepareStatement(sql);
        statement.setString(1, usuario.getNombre());
        statement.setString(2, usuario.getApellido());
        statement.setInt(3, usuario.getEdad());
        statement.setString(4, usuario.getEmail());
        statement.setInt(5, usuario.getId());
        statement.executeUpdate();
        System.out.println("Usuario actualizado exitosamente.");
        return usuario;
    }

    // Método para eliminar un usuario existente de la base de datos
    public void eliminarUsuario(int id) throws SQLException {
        String deleteSql = "DELETE FROM Usuarios WHERE id = ?";
        PreparedStatement deleteStatement = connection.conectar().prepareStatement(deleteSql);
        deleteStatement.setInt(1, id);
        deleteStatement.executeUpdate();
        System.out.println("Usuario eliminado exitosamente.");
    }

    @Override
    public List<Usuario> listarTodosLosUsuarios() {
        return List.of();
    }

    @Override
    public Usuario guardarUsuario(Usuario usuario) {
        return null;
    }

    @Override
    public Usuario obtenerUsuarioPorId(Long id) {
        return null;
    }

    @Override
    public void eliminarUsuario(Long id) {
        try {
            String deleteSql = "DELETE FROM Usuarios WHERE id = ?";
            PreparedStatement deleteStatement = connection.conectar().prepareStatement(deleteSql);
            deleteStatement.setLong(1, id);
            deleteStatement.executeUpdate();
            System.out.println("Usuario eliminado exitosamente.");
        } catch (SQLException e) {
            // Manejar la excepción aquí
            e.printStackTrace(); // Imprimir el stack trace o realizar algún otro manejo de la excepción
        }
    }

    public boolean correoExistente(String email) {
        return false;
    }
  }

