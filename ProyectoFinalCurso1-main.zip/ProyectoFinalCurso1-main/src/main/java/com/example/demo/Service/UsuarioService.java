package com.example.demo.Service;
import com.example.demo.Entity.Usuario;
import org.springframework.stereotype.Service;

import java.util.List;


public interface UsuarioService {
    List<Usuario> listarTodosLosUsuarios();
    Usuario guardarUsuario(Usuario usuario);
    Usuario obtenerUsuarioPorId(Long id);

    static Usuario actualizarUsuario(Usuario usuario) {
        return null;
    }

    void eliminarUsuario(Long id);

}

