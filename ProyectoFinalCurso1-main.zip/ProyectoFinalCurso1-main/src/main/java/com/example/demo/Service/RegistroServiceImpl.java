package com.example.demo.Service;

import com.example.demo.Entity.Registro;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class RegistroServiceImpl implements RegistroService {

        private Map<Long, Registro> registroDatabase = new HashMap<>();
        private Long currentId = 1L;

        @Override
        public Registro crearRegistro(Registro registro) {
            registro.setId(currentId++);
            registroDatabase.put(registro.getId(), registro);
            return registro;
        }

        @Override
        public Registro obtenerRegistroPorId(Long id) {
            return registroDatabase.get(id);
        }

        @Override
        public List<Registro> obtenerTodosLosRegistros() {
            return new ArrayList<>(registroDatabase.values());
        }

        @Override
        public Registro actualizarRegistro(Registro registro) {
            if (registroDatabase.containsKey(registro.getId())) {
                registroDatabase.put(registro.getId(), registro);
                return registro;
            } else {
                throw new RuntimeException("Registro no encontrado con id: " + registro.getId());
            }
        }

        @Override
        public void eliminarRegistro(Long id) {
            if (registroDatabase.containsKey(id)) {
                registroDatabase.remove(id);
            } else {
                throw new RuntimeException("Registro no encontrado con id: " + id);
            }
        }
    }


