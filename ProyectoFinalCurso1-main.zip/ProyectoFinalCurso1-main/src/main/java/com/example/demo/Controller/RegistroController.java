package com.example.demo.Controller;

import com.example.demo.Entity.Usuario;
import com.example.demo.Service.UsuarioServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import java.sql.SQLException;

@Controller
public class RegistroController {

    @Autowired
    private UsuarioServiceImpl usuarioServicio;

    @GetMapping("/vistaRegistro")
    public String mostrarFormularioRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "vistaRegistro";
    }

    @PostMapping("/registro")
    public String registrarUsuario(@ModelAttribute("usuario") Usuario usuario, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "vistaRegistro"; // En caso de errores, volver al formulario de registro
        }

        try {
            // Validar si el correo electrónico ya está registrado
            if (usuarioServicio.correoExistente(usuario.getEmail())) {
                model.addAttribute("error", "El correo electrónico ya está registrado");
                return "registro"; // Mostrar mensaje de error y volver al formulario de registro
            }

            // Registrar el usuario si el correo no está registrado
            usuarioServicio.crearUsuario(usuario);
        } catch (SQLException e) {
            // Manejar cualquier excepción de SQL
            model.addAttribute("error", "Error al registrar el usuario");
            return "vistaRegistro"; // Mostrar mensaje de error y volver al formulario de registro
        }

        return "redirect:/inicio"; // Redireccionar a la página de inicio después del registro exitoso
    }
}
