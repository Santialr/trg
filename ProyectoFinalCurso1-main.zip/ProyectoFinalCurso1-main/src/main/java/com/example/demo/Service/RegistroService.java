package com.example.demo.Service;

import com.example.demo.Entity.Registro;
import java.util.List;

public interface RegistroService {
        Registro crearRegistro(Registro registro);
        Registro obtenerRegistroPorId(Long id);
        List<Registro> obtenerTodosLosRegistros();
        Registro actualizarRegistro(Registro registro);
        void eliminarRegistro(Long id);
    }


