package com.example.demo.Controller;

import com.example.demo.Entity.Principal;
import com.example.demo.Service.CarritoService;
import com.example.demo.Service.JuegoCarritoService;
import com.example.demo.Service.JuegoService;
import com.example.demo.Service.UsuarioServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.logging.Level;
import java.util.logging.Logger;

@Controller
public class PrincipalController {

    private static final Logger LOGGER = Logger.getLogger(PrincipalController.class.getName());

    @Autowired
    private CarritoService carritoService;

    @Autowired
    private JuegoCarritoService juegoCarritoService;

    @Autowired
    private JuegoService juegoService;

    @Autowired
    private UsuarioServiceImpl usuarioService;

    @GetMapping("/principal")
    public String showPrincipalView(Model model) {
        try {
            Principal principal = new Principal(1L, "Título de la Página Principal", "Descripción de la Página Principal");
            model.addAttribute("principal", principal);
            return "vistaPrincipal";
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving principal view", ex);
            return "error";
        }
    }

    @GetMapping("/carritos")
    public String redirectToCarritos(Model model) {
        return "redirect:/carritos/";
    }

    @GetMapping("/contacto")
    public String redirectToContacto(Model model) {
        return "redirect:/contacto/";
    }

    @GetMapping("/juego_carrito")
    public String redirectToJuegoCarrito(Model model) {
        return "redirect:/juego_carrito/";
    }

    @GetMapping("/juegos")
    public String redirectToJuegos(Model model) {
        return "redirect:/juegos/";
    }

    @GetMapping("/usuariosV")
    public String redirectToUsuariosV(Model model) {
        return "redirect:/usuariosV/";
    }
}
