package com.example.demo.Controller;

import com.example.demo.Entity.Usuario;
import com.example.demo.Service.UsuarioService;
import com.example.demo.Service.UsuarioServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@Controller
@RequestMapping("/vistaUsuarios")
public class ControllerVistas {
    private final UsuarioServiceImpl usuarioController = new UsuarioServiceImpl();

    @Autowired
    private UsuarioService servicio;



    @GetMapping("/usuarios")
    public String listarUsuarios(Model modelo) {
        modelo.addAttribute("usuarios", servicio.listarTodosLosUsuarios());
        return "vistaUsuarios"; //nos retorna al archivo usuarios
    }

    @GetMapping("/")
    public String crud(Model model) {
        String valorfinal = "vistaUsuarios";
        try {
            model.addAttribute("usuario", usuarioController.obtenerUsuarios());
        } catch (Exception ex) {
            Logger.getLogger(ControllerVistas.class.getName()).log(Level.SEVERE, null, ex);
            valorfinal = "error";
        }
        return valorfinal;
    }

    @GetMapping("/add")
    public String grettingForm(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "vistaUsuarios";
    }

    @PostMapping("/add")
    public String greetingForm(@ModelAttribute Usuario usuario, Model model) {
        String valorfinal = "redirect:/vistaUsuarios/";
        try {
            usuarioController.crearUsuario(usuario);
            model.addAttribute("usuario", usuarioController.obtenerUsuarios());
        } catch (SQLException ex) {
            Logger.getLogger(ControllerVistas.class.getName()).log(Level.SEVERE, null, ex);
            valorfinal = "error";
        }
        return valorfinal;
    }

    @GetMapping("/editar")
    public String modificar(@RequestParam("cod_usuario") int id, Model model) {
        String valorfinal = "/editar";
        try {
            model.addAttribute("usuario", usuarioController.buscar(id));
        } catch (SQLException ex) {
            Logger.getLogger(ControllerVistas.class.getName()).log(Level.SEVERE, null, ex);
            valorfinal = "error";
        }
        return valorfinal;
    }

    @PostMapping("/editar")
    public String modificarBBDD(@ModelAttribute Usuario usuario, Model model) {
        String valorfinal = "redirect:/vistaUsuarios";
        try {
            usuarioController.actualizarUsuario(usuario);
            model.addAttribute("usuario", usuarioController.obtenerUsuarios());
        } catch (SQLException ex) {
            Logger.getLogger(ControllerVistas.class.getName()).log(Level.SEVERE, null, ex);
            valorfinal = "error";
        }
        return valorfinal;
    }

    @GetMapping("/eliminar")
    public String eliminar(@RequestParam("cod_usuario") int id, Model model) {
        String valorfinal = "redirect:/vistaUsuarios";
        try {
            usuarioController.eliminarUsuario(id);
            model.addAttribute("usuario", usuarioController.obtenerUsuarios());
        } catch (SQLException ex) {
            Logger.getLogger(ControllerVistas.class.getName()).log(Level.SEVERE, null, ex);
            valorfinal = "error";
        }
        return valorfinal;
    }

    @PostMapping("/usuarios/nuevo")
    public String agregarUsuarios(@ModelAttribute Usuario usuario, Model modelo) {
        try {
            // Aquí puedes llamar al servicio para guardar el usuario en la base de datos
            servicio.guardarUsuario(usuario);
            modelo.addAttribute("mensaje", "Usuario agregado correctamente");
        } catch (Exception e) {
            // Manejo de errores, por ejemplo, mostrar un mensaje de error en la vista
            modelo.addAttribute("error", "Error al agregar usuario: " + e.getMessage());
        }
        return "agregarUsuarios"; // Puedes retornar la misma vista con mensajes de éxito o error
    }


    @PostMapping("/usuarios")
    public String guardarUsuario(@ModelAttribute("usuario") Usuario usuario) {
        servicio.guardarUsuario(usuario);
        return "redirect:/vistaUsuarios/usuarios";
    }

    @GetMapping("/usuarios/editar/{id}")
    public String mostrarFormularioDeEditar(@PathVariable Long id, Model modelo) {
        Usuario usuario = servicio.obtenerUsuarioPorId(id);
        if (usuario != null) {
            modelo.addAttribute("usuario", usuario);
            return "modificarUsuarios";
        }
        return "redirect:/vistaUsuarios/usuarios";
    }

    @PostMapping("/usuarios/{id}")
    public String actualizarUsuario(@PathVariable Long id, @ModelAttribute("usuario") Usuario usuario, Model modelo) {
        Usuario usuarioExistente = servicio.obtenerUsuarioPorId(id);
        if (usuarioExistente != null) {
            usuarioExistente.setId(Math.toIntExact(id));
            usuarioExistente.setNombre(usuario.getNombre());
            usuarioExistente.setApellido(usuario.getApellido());
            usuarioExistente.setEdad(usuario.getEdad());
            usuarioExistente.setEmail(usuario.getEmail());

            UsuarioService.actualizarUsuario(usuarioExistente);
        }
        return "redirect:/vistaUsuarios/usuarios";
    }


}
